import javax.swing.JOptionPane;
public class sum{
    public static void main(String[] args){
        String strNum1, strNum2;

        strNum1 = JOptionPane.showInputDialog(null,
        "Please input the first number:","Input the first number",JOptionPane.INFORMATION_MESSAGE);
        
        strNum2 = JOptionPane.showInputDialog(null,
        "Please input the second number:","Input the second number",JOptionPane.INFORMATION_MESSAGE);
        
        double num1 = Double.parseDouble(strNum1);
        double num2 = Double.parseDouble(strNum2);
        
        double sum = num1 + num2;
        double difference = num1 - num2;
        double product = num1 * num2;
        String message;
        
        if(num2 == 0){
            message = "Sum: " + num1 + " + " + num2 + " = " + sum +
                      "\nDifference: " + num1 + " - " + num2 + " = " + difference +
                      "\nProduct: " + num1 + " * " + num2 + " = " + product +
                      "\nQuotient: Error (division by zero)";
        } else {
            double quotient = num1 / num2;
            message = "Sum: " + num1 + " + " + num2 + " = " + sum +
                      "\nDifference: " + num1 + " - " + num2 + " = " + difference +
                      "\nProduct: " + num1 + " * " + num2 + " = " + product +
                      "\nQuotient: " + num1 + " / " + num2 + " = " + quotient;
        }
        
        JOptionPane.showMessageDialog(null, message);
        System.exit(0);
    }
}
