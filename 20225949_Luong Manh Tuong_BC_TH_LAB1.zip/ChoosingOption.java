import javax.swing.JOptionPane;

public class ChoosingOption {
    public static void main(String[] args) {
        int option = JOptionPane.showConfirmDialog(null, 
            "Do you want to upgrade to the first class ticket?",
            "Upgrade Confirmation", JOptionPane.YES_NO_CANCEL_OPTION);

        if (option == JOptionPane.YES_OPTION) {
            JOptionPane.showMessageDialog(null, "You have chosen to upgrade.");
        } else if (option == JOptionPane.NO_OPTION) {
            JOptionPane.showMessageDialog(null, "You have chosen to stay in the current class.");
        } else {
            JOptionPane.showMessageDialog(null, "You have cancelled the operation.");
        }
    }
}