import javax.swing.JOptionPane;

public class LinearEquationSolver {
    public static void main(String[] args) {
        String strA = JOptionPane.showInputDialog(null, 
                        "Please input the coefficient a (a ≠ 0):", 
                        "Input coefficient a", JOptionPane.INFORMATION_MESSAGE);
        String strB = JOptionPane.showInputDialog(null, 
                        "Please input the coefficient b:", 
                        "Input coefficient b", JOptionPane.INFORMATION_MESSAGE);

        double a = Double.parseDouble(strA);
        double b = Double.parseDouble(strB);

        if (a == 0) {
            JOptionPane.showMessageDialog(null, 
                "Error: 'a' cannot be zero in a linear equation.");
        } else {
            double solution = -b / a;
            JOptionPane.showMessageDialog(null, 
                "The solution of the equation " + a + "x + " + b + " = 0 is x = " + solution);
        }

        System.exit(0);
    }
}
