import java.util.Scanner;

public class DayInMonth { // Ensure this matches your file name

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        String monthInput;
        int yearInput;
        int daysInMonth;
        
        while (true) {
            System.out.print("Enter a month (full name, abbreviation, or number): ");
            monthInput = scanner.nextLine().trim();

            System.out.print("Enter a year (four-digit non-negative number): ");
            try {
                yearInput = Integer.parseInt(scanner.nextLine().trim());
                
                if (yearInput < 0) {
                    System.out.println("Invalid year. Please enter a non-negative four-digit number.");
                    continue;
                }
            } catch (NumberFormatException e) {
                System.out.println("Invalid year format. Please enter a valid four-digit number.");
                continue;
            }

            int month = convertMonthToNumber(monthInput);
            if (month == -1) {
                System.out.println("Invalid month. Please try again.");
                continue;
            }
            
            daysInMonth = getDaysInMonth(month, yearInput); // Call the getDaysInMonth method
            System.out.println("The number of days in " + monthInput + " " + yearInput + " is: " + daysInMonth);
            break;
        }
        
        scanner.close();
    }
    
    private static int convertMonthToNumber(String month) {
        month = month.toLowerCase();
        switch (month) {
            case "january": case "jan": case "jan.":
                return 1;
            case "february": case "feb": case "feb.":
                return 2;
            case "march": case "mar": case "mar.":
                return 3;
            case "april": case "apr": case "apr.":
                return 4;
            case "may":
                return 5;
            case "june": case "jun": case "jun.":
                return 6;
            case "july": case "jul": case "jul.":
                return 7;
            case "august": case "aug": case "aug.":
                return 8;
            case "september": case "sep": case "sep.":
                return 9;
            case "october": case "oct": case "oct.":
                return 10;
            case "november": case "nov": case "nov.":
                return 11;
            case "december": case "dec": case "dec.":
                return 12;
            default:
                try {
                    int monthNumber = Integer.parseInt(month);
                    if (monthNumber >= 1 && monthNumber <= 12) {
                        return monthNumber;
                    }
                } catch (NumberFormatException e) {
                    return -1;
                }
                return -1;
        }
    }

    private static int getDaysInMonth(int month, int year) {
        switch (month) {
            case 1: case 3: case 5: case 7: case 8: case 10: case 12:
                return 31;
            case 4: case 6: case 9: case 11:
                return 30;
            case 2:
                return isLeapYear(year) ? 29 : 28;
            default:
                return -1;
        }
    }

    private static boolean isLeapYear(int year) {
        if (year % 4 == 0) {
            if (year % 100 == 0) {
                return year % 400 == 0;
            } else {
                return true;
            }
        }
        return false;
    }
}
